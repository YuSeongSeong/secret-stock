package com.example.teamproject

import android.app.TabActivity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TabHost
@Suppress("deprecation")

class Menu : TabActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        var host = this.tabHost
        host.setup()
        var spec = host.newTabSpec("tab1")
        spec.setContent(R.id.chart)
        host.addTab(spec)
    }
}